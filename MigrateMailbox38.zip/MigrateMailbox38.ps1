﻿#
# MigrateMailbox38.ps1
# 11/15/2015
################################################################################
# Script Parameters
################################################################################

# $netId: Passed in Net ID of the mailbox this script will migrate
param([parameter(Mandatory=$True,HelpMessage='NU NetID')]
[String]$netid)


################################################################################
# Script Options
################################################################################

# Set the option to stop this script on any unhandled errors
$ErrorActionPreference = "Stop" 

################################################################################
# Script Constants
################################################################################

# Load Snappins
import-module activedirectory
Get-PSSnapin -Registered |Add-PSSnapin

# Log files location
$LogFilesPath = 'C:\logs'

# Success log file name
$LogFileName = 'MigrateMailbox.log'

# Error log file name
$ErrorLogFileName = 'MigrateMailbox.err.log'

# Success audit log file name

$SuccessAuditLogFileName = 'MigrateSuccesses.log'

# Error audit log file name
$FailureAuditErrorLogFileName = 'MigrateFailures.err.log'

# LDAP Root Path
$LDAPPath = 'LDAP://ads.northwestern.edu/DC=ads,DC=northwestern,DC=edu'

# Active Directory Properties to load
$ADPropertiesToLoad = ( 'cn', 'displayName', 'distinguishedname',
						'nuexchangeaccountoldtype', 'nuexchangeaccounttype', 
						'nuexchangealternateemail',
						'nuexchangebasequota', 'nuexchangeforwardingaddress',
						'nuexchangehasoptedin', 'nuexchangeprimaryemail',
						'nuexchangevisible', 'proxyaddresses')
					
# Authoritative Email Domains
$AuthEmailDomains = ('e.northwestern.edu',
                     'law.northwestern.edu',
					 'northwestern.edu',
                     'kellogg.northwestern.edu',
                     'earth.northwestern.edu')

                        
						

# Local Email Domains
$LocalEmailDomains = (	'casbah.it.northwestern.edu',
						'merle.it.northwestern.edu',
						'hecky.it.northwestern.edu',
						'mail.it.northwestern.edu',
						'lulu.it.northwestern.edu',
						'clarkes.it.northwestern.edu',
						'e.northwestern.edu',
						'northwestern.edu',
						'law.northwestern.edu',
						'qatar.northwestern.edu',
						'icair.org',
						'wcas.northwestern.edu',
						'itcs.northwestern.edu',
						'pim.northwestern.edu',
						'kellogg.northwestern.edu')

# Vanity Email Domains
$VanityEmailDomains = (  'exchangeDelegation.northwestern.edu', 
                    'our.northwestern.edu', 
                    'relay.kellogg.northwestern.edu', 
                    'exchtest.northwestern.edu',
                    'alumni.northwestern.edu', 
                    'nualumni.com',
                    'wnur.org',
                    'nuwildcat.mail.onmicrosoft.com',
                    'earth.northwestern.edu',
                    'chem.northwestern.edu')





################################################################################
# Script Functions
################################################################################

# Writes out a single line to the log file
function writeLog([String]$line)
{
	Add-Content "$LogFilesPath\$LogFileName" "$(get-date -f 'yyyy-MM-dd HH:mm:ss') - $netId - $line"
}

# Writes out a single line to the log file
function writeError([String]$line)
{
	Add-Content "$LogFilesPath\$ErrorLogFileName" "$(get-date -f 'yyyy-MM-dd HH:mm:ss') - $netId - $line"
	
}

# Writes out a single line to the failure audit log file
function writeAuditFailureError()
{
	Add-Content "$LogFilesPath\$FailureAuditErrorLogFileName" "$(get-date -f 'yyyy-MM-dd HH:mm:ss') - $netId - $line"
	
}

# Search Active Directory for a user object and return the data we are interested in
function getADUserData([String]$userName)
{
	try
	{
		# create and configure a directory searcher object
		$filterString = "(&(objectCategory=User)(name=$userName))"
		$objSearcher = New-Object System.DirectoryServices.DirectorySearcher
		$objSearcher.SearchRoot = [ADSI]$LDAPPath
		$objSearcher.PageSize = 2
		$objSearcher.Filter = $filterString
		$objSearcher.SearchScope = "Subtree"
	
		# set the properties we want to load on search
		foreach ($i in $ADPropertiesToLoad)
		{
			[Void]$objSearcher.PropertiesToLoad.Add($i)
		}

		# do the search
		$colResults = $objSearcher.FindAll()
		
		# fail if we did not find any users
		if ($colResults.Count -eq 0)
		{
			Throw (New-Object System.Exception 'Could not find a user with the specified Net ID')
		}
		
		# fail if we found more that one user
		if ($colResults.Count -gt 1)
		{
			Throw (New-Object System.Exception 'Found more than one user object with the same Net ID')
		}
		
		# populate our script values from the AD object
		foreach ($objResult in $colResults)
		{
			$objItem = $objResult.Properties
			
			# store all the data from AD in a complex type
			$userData = New-Object PSObject
			if ($objItem.cn) {
			    $userData | Add-Member -type NoteProperty -name NetID -Value $objItem.cn[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name Netid -Value $objItem.cn
            }
			if ($objItem.displayName) {
			    $userData | Add-Member -type NoteProperty -name DisplayName -Value $objItem.displayname[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name DisplayName -Value $objItem.displayname
            }
            if ($objItem.distinguishedname) {
			    $userData | Add-Member -type NoteProperty -Name DN -Value $objItem.distinguishedname[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name DN -Value $objItem.distinguishedname
            }
			if ($objItem.proxyaddresses) {
                $userData | Add-Member -type NoteProperty -Name ProxyAddresses -Value $objItem.proxyaddresses
            } else {
                $userData | Add-Member -type NoteProperty -Name ProxyAddresses -Value $objItem.proxyaddresses
            }
            if ($objItem.nuexchangeaccountoldtype) {
			     $userData | Add-Member -type NoteProperty -Name OldType -Value $objItem.nuexchangeaccountoldtype[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name OldType -Value $objItem.nuexchangeaccountoldtype
            }
			if ($objItem.nuexchangeaccounttype)  {
                $userData | Add-Member -type NoteProperty -Name Type -Value $objItem.nuexchangeaccounttype[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name Type -Value $objItem.nuexchangeaccounttype
            }
			if ($objItem.nuexchangealternateemail) {
                $userData | Add-Member -type NoteProperty -Name AltEmail -Value $objItem.nuexchangealternateemail[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name AltEmail -Value $objItem.nuexchangealternateemail
            }
            if ($objItem.nuexchangebasequota) {
			     $userData | Add-Member -type NoteProperty -Name BaseQ -Value $objItem.nuexchangebasequota[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name BaseQ -Value $objItem.nuexchangebasequota
            }
            if ($objItem.nuexchangeforwardingaddress) {
			     $userData | Add-Member -type NoteProperty -Name FwdEmail -Value $objItem.nuexchangeforwardingaddress[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name FwdEmail -Value $objItem.nuexchangeforwardingaddress
            }
            if ($objItem.nuexchangehasoptedin) {
			     $userData | Add-Member -type NoteProperty -Name OptIn -Value $objItem.nuexchangehasoptedin[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name OptIn -Value $objItem.nuexchangehasoptedin
            }
            if ($objItem.nuexchangeprimaryemail) {
			     $userData | Add-Member -type NoteProperty -Name PrimaryEmail -Value $objItem.nuexchangeprimaryemail[0]
            } else {     
                $userData | Add-Member -type NoteProperty -Name PrimaryEmail -Value $objItem.nuexchangeprimaryemail
            }
            if ($objItem.nuexchangevisible) {
			     $userData | Add-Member -type NoteProperty -Name Visible -Value $objItem.nuexchangevisible[0]
            } else {
                $userData | Add-Member -type NoteProperty -Name Visible -Value $objItem.nuexchangevisible
            }
           if ($userData.BaseQ) {
				$userData | Add-Member -type NoteProperty -Name Warn -Value (([INT]$userData.BaseQ * .98).tostring() + 'MB')
	            $userData | Add-Member -type NoteProperty -Name ProSend -Value (($userData.BaseQ).tostring() + 'MB')
	            $userData | Add-Member -type NoteProperty -Name ProSendRec -Value (([INT]$userData.BaseQ * 1.05).tostring() + 'MB')
	        }else {
				$userData | Add-Member -type NoteProperty -Name Warn -Value '0MB'
	            $userData | Add-Member -type NoteProperty -Name ProSend -Value '0MB'
	            $userData | Add-Member -type NoteProperty -Name ProSendRec -Value '0MB'
			}
			
			$userData | Add-Member -type NoteProperty -Name PrimaryDatabase -Value ''
            

			return $userData
		}
		
		$objSearcher = $null
	}
	catch
	{
		Throw (New-Object System.Exception ('E0002: {0}' -f $_.Exception.Message))
	}
}



# Writes out a single line to the success audit log file
function writeAuditSuccessLog([string]$auditline)
{
			Add-Content "$LogFilesPath\$SuccessAuditLogFileName" "$(get-date -f 'yyyy-MM-dd HH:mm:ss') - $netId - $auditline"
}


function ChangeGalVis($userData)
{
    try
    {
            if (($userData.type.tolower() -eq 'full') -or ($userData.type.tolower() -eq 'fwdwithemail')) {
                if ($userData.Visible.toupper() -eq 'FALSE') {
                    set-mailbox -identity $userData.DN -HiddenFromAddressListsEnabled $true -domaincontroller evcspidmgw1.ads.northwestern.edu
                } elseif ($userData.Visible.toupper() -eq 'TRUE') {
                    set-mailbox -identity $userData.DN -HiddenFromAddressListsEnabled $false -domaincontroller evcspidmgw1.ads.northwestern.edu
                } else {
                    Throw (New-Object System.Exception 'Bad Value for Visibility')
                }
            } elseif (($userData.type.tolower() -eq 'fwdnoemail') -or ($userData.type.tolower() -eq 'listing')){
                if ($userData.Visible.toupper() -eq 'FALSE') {
                    set-mailuser -identity $userData.DN -HiddenFromAddressListsEnabled $true  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
                } elseif ($userData.Visible.toupper() -eq 'TRUE') {
                    set-mailuser -identity $userData.DN -HiddenFromAddressListsEnabled $false  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
                } else {
                    Throw (New-Object System.Exception 'Bad Value for Visibility')
                }
            } else {
                Throw (New-Object System.Exception 'Bad Value for User Type')
            }
            return $userData
    }
    catch
    {
            Throw (New-Object System.Exception ('E0017: {0}' -f $_.Exception.Message))
	}
}

function selectPrimaryMailboxDatabase($userdata)
{
    $minusercount = 500 # Max number of mailboxes allowed in a database
    $RandomCount = 103  # To speed things up, this can be changed to something lower to only check a random subset of available dbs (value of "yes" in table below)

    try
    {
        $dbs = Get-MailboxDatabase mdb* | Where-Object{!$_.IsSuspendedFromProvisioning} | Get-Random -Count $RandomCount
                
        foreach ($mbxdb in $dbs)
       	{
    		$currentctr = 0    
            $currentctr = Get-MDBMailboxCount -DN $mbxdb.DistinguishedName
            
    		if ($currentctr -lt $minusercount)
       		{
    			$minusercount = $currentctr
    			$dbnamesel = $mbxdb.name
    		}
    	}
        if ($dbnamesel)
    	{
            $userData.PrimaryDatabase = $dbnamesel
    	} 
        else 
        {
    		Throw (New-Object System.Exception ('E0043: No Primary DB selected'))
    	}

    }
    catch
    {
    	Throw (New-Object System.Exception ('E0044: {0}' -f $_.Exception.Message))
    }
    
    return $userData
}


function Get-MDBMailboxCount ([string]$DN) { 

$Searcher = New-Object System.DirectoryServices.DirectorySearcher 

$Searcher.SearchRoot = New-Object System.DirectoryServices.DirectoryEntry ('LDAP://ads.northwestern.edu/DC=ads,DC=northwestern,DC=edu') 

$Searcher.Filter = "(&(objectClass=user)(homeMDB=$DN))" 

$Searcher.PageSize = 10000 

$Searcher.SearchScope = "Subtree" 

$results = $Searcher.FindAll()

$returnValue = $results.Count

#dispose of the search and results properly to avoid a memory leak
#$Searcher.Dispose()
#results.Dispose()

return $returnValue 

}


# Set the old type to the new type
function OldTypeToType($userData)
{
	try
	{
			$string = "LDAP://" + $userData.DN
            $userObj = [ADSI]$string

			
            $userObj.put(“nuexchangeaccountoldtype”, $userData.type)

            $userObj.setInfo()

			return $userData
	}
	catch
	{
            Throw (New-Object System.Exception ('E0013: {0}' -f $_.Exception.Message))
	}
}


# Returns True if the user's primary email address is in one of our authoritative domains
function isPrimaryAddressInAuthDomain($userData)
{
	# pull the domain name from the user's primary email address
	$primaryDomain = $userData.PrimaryEMail.Split('@')[1]
	
	$result = $false
	foreach ($authDomain in $AuthEmailDomains)
	{
		if ($primaryDomain -eq $authDomain)
		{
			$result = $true
		}
	}
	
	return $result
}

function removeMD($userData)
{
		
	#pull the domain name from the user's primary email address
	
	$primaryAddy = $userData.PrimaryEMail
    $checkMd = $primaryAddy.split("@")[1]
    $userAlias = $primaryAddy.split("@")[0]
	
	$checkAlt = $userData.AltEmail.replace(($userAlias + "@northwestern.edu,"),"")
	
	if ($checkMd -eq "md.northwestern.edu"){
		$newPrimaryAddy = $userAlias + "@northwestern.edu"
		
		#Update Primary email address and return
     	$userData.PrimaryEMail = $newPrimaryAddy 
     	
		$userData.AltEmail = $checkAlt
		} 
		$checkAlt = $userData.AltEmail.replace(($userAlias + "@md.northwestern.edu,"),"")
		$userData.AltEmail = $checkAlt
   
	return $userData
  
}



# Returns True if the passed-in email address is in one of our "local" domains
function isEmailAddressInLocalDomain($address)
{
	# pull the domain name from the user's primary email address
	$inDomain = $address.Split('@')[1]
	
	$result = $false
	foreach ($domain in $LocalEmailDomains)
	{
		if ($inDomain -eq $domain)
		{
			$result = $true
		}
	}
	
	return $result
}


#Assign email addresses new mailbox
function updateNewProxyAddresses($userData)
{
	$newProxyAddresses = New-Object "System.Collections.Generic.List``1[System.String]"

	# first, add the primary email address with a "SMTP:" prefix
	$temp = 'SMTP:{0}' -f $userData.PrimaryEmail
	$newProxyAddresses.Add($temp)
	
	
	# next, go through each existing proxy address... 
	# Do not add the default (identified by "SMTP:" in caps)
	# Add any domain identified as a "local" domain
	
	if ($userData.ProxyAddresses) {
		foreach ($address in $userData.ProxyAddresses)
		{
			if ($address -and (!$address.StartsWith('SMTP:'))) {
	            if (!$address.StartsWith('smtp:')) {
					if($address.StartsWith('X500:') -or ($address.StartsWith('x500:'))){
					$newProxyAddresses.add([Microsoft.Exchange.Data.CustomProxyAddress]($address.toLOWER()))
					}
					else{
					$newProxyAddresses.Add($address)}
	            } elseif (isEmailAddressInLocalDomain $address){
				     $newProxyAddresses.Add($address)
	            }
	        }
	    }
	}
	
	# finally, add in all address in the alternate address list 
	# which are not already in our new proxy addresses list
	if ($userData.AltEmail) {
		foreach ($address in $userData.AltEmail.Split(','))
		{
			if ($address -and (!$newProxyAddresses.Contains(('smtp:{0}' -f $address.Trim())))-and (!($address -match "fsm.northwestern.edu") -and (!($address -match "md.northwestern.edu"))-and (!($address -match "u.northwestern.edu"))))
			{
				$temp = 'smtp:{0}' -f $address.Trim()
				$newProxyAddresses.Add($temp)
			}
		}
	}
	# update the ProxyAddresses value and return
	$userData.ProxyAddresses = $newProxyAddresses.ToArray()

	return $userData
}

#Add new primary 
function updateProxyAddresses($userData)
{
      $newProxyAddresses = New-Object "System.Collections.Generic.List``1[System.String]"
      
      #Get current mailbox Primary Email Address
      $oldPrimary = (get-mailbox $userdata.DN).primarysmtpaddress
      $oldPrimary = $oldprimary.local + "@" + $oldprimary.domain
      $tempold = 'smtp:{0}' -f $oldPrimary 
      
      #Set new Primary to a variable
      $newPrimary = $userData.PrimaryEmail
      
      # Add the primary email address with a "SMTP:" prefix
      $temp = 'SMTP:{0}' -f $userData.PrimaryEmail
      $newProxyAddresses.Add($temp)
            
      #Count proxy addresses if less than ten add old primary
      $smtpProxyLimit = 10
 if (($userData.PrimaryEmail.toUpper() -ne $oldPrimary.toUpper()) –and (($userData.ProxyAddresses |?{$_.startsWith(‘smtp:’)}).count –lt $smtpProxyLimit)){
      $newProxyAddresses.Add($tempold) 
      }
 
  if ($userData.ProxyAddresses) {
		foreach ($address in $userData.ProxyAddresses)
		{
			if ($address -and (!$address.StartsWith('SMTP:')) -and ($address -ne($userdata.ProxyAddresses -match $temp))) {
	            if (!$address.StartsWith('smtp:')) {
					if($address.StartsWith('X500:') -or ($address.StartsWith('x500:'))){
					$newProxyAddresses.Add([Microsoft.Exchange.Data.CustomProxyAddress]($address.toLOWER()))
					}
					else{
					$newProxyAddresses.Add($address)}
	            } elseif (isEmailAddressInLocalDomain $address){
				     $newProxyAddresses.Add($address)
	            }
	        }
	    }
	}

		$userData.ProxyAddresses = $newProxyAddresses.ToArray()
 
      	return $userData
}


## Changed Contact Display Name to User Display Name
function setForwardingContact($userData)
{
    try
    {
			$destcontact = $null
			try 
			{
                if ($userData.FwdEmail) {
				    $destcontact = get-mailcontact -identity $userData.FwdEmail -domaincontroller evcspidmgw1.ads.northwestern.edu
                } else {
                    Throw (New-Object System.Exception 'No forwarding address specified')
                }
			}
			catch
			{
			}
            if (!$destcontact) {
                $looptctr = 0;
                do {
                    $loopctr++
                    $contactname = "EC." + $netid + "." + $loopctr
					$destcontact = $null
					try
					{
                    	$destcontact = get-mailcontact -identity $contactname -domaincontroller evcspidmgw1.ads.northwestern.edu
					}
					catch
					{
					}
                } while (($destcontact) -and ($loopctr -le 15))
                if ($loopctr -eq 15) {
                    Throw (New-Object System.Exception '$netid has too many forwarding contacts')
                } else {
                    $destcontact = new-mailcontact -name $contactname -DisplayName $userData.displayname -ExternalEmailAddress $userData.FwdEmail -primarysmtpaddress $userData.FwdEmail -OrganizationalUnit "ads.northwestern.edu/Contacts" -domaincontroller evcspidmgw1.ads.northwestern.edu
            	}
			} 

            set-mailcontact -identity $destcontact.DistinguishedName -HiddenFromAddressListsEnabled $true -domaincontroller evcspidmgw1.ads.northwestern.edu
            set-mailbox -identity $userData.DN -ForwardingAddress $destcontact.distinguishedname
            
            return $userData
 	}
    catch
	{
            Throw (New-Object System.Exception ('E0015: {0}' -f $_.Exception.Message))
	}
} 

function VanityDomainMailbox ($userData)
{
    $user = (get-mailbox $userData.DN).EmailAddresses
            $addresses = $user.smtpaddress

            foreach ($object in $addresses){
            $address = $object.Split('@')[1]

            if($VanityEmailDomains -contains $address ){
            $line = $userData.NetID + 'Contains vanity domain address' + $address

        writeError $line
        exit 1
        exit 1
    }
    else {

       #write-host "Does NOT contain a vanity address"

       return $userData
    }
    }
      
}

function VanityDomainMailUser ($userData)
{
    $user = (get-mailuser $userData.DN).EmailAddresses
            $addresses = $user.smtpaddress

            foreach ($object in $addresses){
            $address = $object.Split('@')[1]

            if($VanityEmailDomains -contains $address ){
                $line = $userData.NetID + 'Contains vanity domain address' + $address
        writeError $line
        exit 1
        exit 1

    }
    else {

       #write-host "Does NOT contain a vanity address"

       return $userData
    }
    }
      
}

# mail-enable existing AD user and set primary email address, will add alternate email addresses
function NONETOFULL($userData)
{
	try
	{

            if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Conversion to full mailbox user requires primary email address to be in authoritative domain')
            } 
			
			#remove MD email addresses
			$userData = removeMD $userData
            #update proxy addresses for new mailbox
            $userData = updateNewProxyAddresses $userData
			$userData = updateNewProxyAddresses $userData
            #select primary mailbox database
            $userdata = selectprimarymailboxdatabase $userdata
			
            enable-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -database $userdata.PrimaryDatabase -domaincontroller evcspidmgw1.ads.northwestern.edu
 			
            #set Primary Email Address 
            set-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
            set-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
            #set alternate Email Addresses
			set-Mailbox -Identity $userData.DN -EmailAddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
            #set Mailbox quotas
			set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -domaincontroller evcspidmgw1.ads.northwestern.edu
            
            #set owa policy
			set-casmailbox -identity $userData.DN -owamailboxpolicy Default -domaincontroller evcspidmgw1.ads.northwestern.edu

            #set if user should be visable or not in gal
		   	$userData = ChangeGalVis $userData
            #change old type to new type
            $userData = OldTypeToType $userData
			
			return $userData
	}
	catch
	{
            Throw (New-Object System.Exception ('E0012: {0}' -f $_.Exception.Message))
	}
}


function NONETOFWDWEMAIL($userData)
{
    try
    {

           if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Conversion to forwarding mailbox user requires primary email address to be in authoritative domain')
            } 
			
			$userData = removeMD $userData
			$userData = updateNewProxyAddresses $userData
			$userData = updateNewProxyAddresses $userData
 			$userdata = selectprimarymailboxdatabase $userdata
			
            enable-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -database $userdata.PrimaryDatabase -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-Mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-Mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
	
			set-casmailbox -identity $userData.DN -owamailboxpolicy Default -domaincontroller evcspidmgw1.ads.northwestern.edu
	
            $userData = setForwardingContact $userData
			$userData = ChangeGalVis $userData
            $userData = updateProxyAddresses $userData
			$userData = OldTypeToType $userData
  
  			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0014: {0}' -f $_.Exception.Message))
	}    
}


function NONETOFWDNOEMAIL($userData)
{
    try
    {

            #set email addresses
            $userData = updateNewProxyAddresses $userData         
            #create mail user 
            enable-mailuser -identity $userData.DN  -externalemailaddress $userData.FwdEmail -domaincontroller evcspidmgw1.ads.northwestern.edu
            #set mailuser email addresses
            set-mailuser -identity $userData.DN -EmailAddressPolicyEnabled $false -emailaddresses $userData.ProxyAddresses  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            
            $userData = ChangeGalVis $userData
			$userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0016: {0}' -f $_.Exception.Message))
	}    
}


function NONETOLISTING($userData)
{
    try
    {
                                  
			enable-mailuser -identity $userData.DN  -externalemailaddress $userData.PrimaryEmail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailuser -identity $userData.DN -EmailAddressPolicyEnabled $false -PrimarySmtpAddress $userData.PrimaryEmail  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0018: {0}' -f $_.Exception.Message))
	}
    
}

    


function LISTINGTOFULL($userData)
{
	try
	{
            

            if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Conversion to full mailbox user requires primary email address to be in authoritative domain')
            } 
			
            
			$userData = removeMD $userData
			$userData = updateNewProxyAddresses $userData
            $userdata = selectprimarymailboxdatabase $userdata
			
			enable-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -database $userdata.PrimaryDatabase -domaincontroller evcspidmgw1.ads.northwestern.edu
 			set-Mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-Mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu

			set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			
			set-casmailbox -identity $userData.DN -owamailboxpolicy Default -domaincontroller evcspidmgw1.ads.northwestern.edu
					
            $userData = updateNewProxyAddresses $userData
			$userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData
			

			return $userData
	}
	catch
	{
            Throw (New-Object System.Exception ('E0019: {0}' -f $_.Exception.Message))
	}
}


function LISTINGTOFWDNOEMAIL($userData)
{
    try
    {
            $userdata = VanityDomainMailuser $userdata
            $userdata = VanityDomainMailuser $userdata

            $userdata = VanityDomainMailuser $userdata
            $userdata = VanityDomainMailuser $userdata

            $userData = updateNewProxyAddresses $userData
                        
            set-mailuser -identity $userData.DN -externalemailaddress $userData.FwdEmail -EmailAddressPolicyEnabled $false -emailaddresses $userData.ProxyAddresses  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0020: {0}' -f $_.Exception.Message))
	}
}



function LISTINGTOFWDWEMAIL($userData)
{
   try
    {
            

            if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Conversion to forwarding mailbox user requires primary email address to be in authoritative domain')
            }
			
            $userData = removeMD $userData
			$userData = removeMD $userData
			$userData = updateNewProxyAddresses $userData
			$userData = updateNewProxyAddresses $userData
            $userdata = selectprimarymailboxdatabase $userdata
			
			enable-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -database $userdata.PrimaryDatabase -domaincontroller evcspidmgw1.ads.northwestern.edu
 			set-Mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-Mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			
			set-casmailbox -identity $userData.DN -owamailboxpolicy Default -domaincontroller evcspidmgw1.ads.northwestern.edu
			
            $userData = setForwardingContact $userData
			$userData = ChangeGalVis $userData
            $userData = updateNewProxyAddresses $userData
			$userData = OldTypeToType $userData
			
			return $userData
  
    }
	catch
	{
            Throw (New-Object System.Exception ('E0021: {0}' -f $_.Exception.Message))
	}
}


function LISTINGTOLISTING($userData)
{
    try
    {
            $userdata = VanityDomainMailuser $userdata
            $userdata = VanityDomainMailuser $userdata
            $userdata = VanityDomainMailuser $userdata

            $userData = updateNewProxyAddresses $userData

            set-mailuser -identity $userData.DN -externalemailaddress $userData.PrimaryEmail  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            set-mailuser -identity $userData.DN -EmailAddressPolicyEnabled $false -primarysmtpaddress $userData.primaryemail  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
           
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0022: {0}' -f $_.Exception.Message))
	}
}


function LISTINGTONONE($userData)
{
			
    try
    {		

            disable-mailuser -identity $userData.DN -Confirm:$false -domaincontroller evcspidmgw1.ads.northwestern.edu
            
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
		Throw (New-Object System.Exception ('E0023: {0}' -f $_.Exception.Message))
	}
}

function FWDNOEMAILTOFULL($userData)
{
	try
	{
            

            if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Conversion to full mailbox user requires primary email address to be in authoritative domain')
            }
			
			$userData = removeMD $userData
			$userData = updateNewProxyAddresses $userData
			$userData = updateNewProxyAddresses $userData
            $userdata = selectprimarymailboxdatabase $userdata
			
			enable-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -database $userdata.PrimaryDatabase -domaincontroller evcspidmgw1.ads.northwestern.edu
 			set-Mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-Mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu

			Set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
            Set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
            Set-Mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -domaincontroller evcspidmgw1.ads.northwestern.edu
			
			set-casmailbox -identity $userData.DN -owamailboxpolicy Default -domaincontroller evcspidmgw1.ads.northwestern.edu
			
			set-Mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-Mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-Mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-Mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			
            $userData = updateNewProxyAddresses $userData
			$userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData

			return $userData
	}
	catch
	{
            Throw (New-Object System.Exception ('E0024: {0}' -f $_.Exception.Message))
	}
}

function FWDNOEMAILTOFWDNOEMAIL($userData)
{

   try
    {		
			
            $userdata = VanityDomainMailuser $userdata
            $userdata = VanityDomainMailuser $userdata
            
            $userdata = VanityDomainMailuser $userdata
            $userdata = VanityDomainMailuser $userdata

            $userData = updateNewProxyAddresses $userData
                                    
            set-mailuser -identity $userData.DN -externalemailaddress $userData.FwdEmail -EmailAddressPolicyEnabled $false -emailaddresses $userData.ProxyAddresses  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            set-mailuser -identity $userData.DN -externalemailaddress $userData.FwdEmail  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            set-mailuser -identity $userData.DN -EmailAddressPolicyEnabled $false -emailaddresses $userData.ProxyAddresses  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0025: {0}' -f $_.Exception.Message))
    }
}



function FWDNOEMAILTOFWDWEMAIL($userData)
{
   try
    {
            

            if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Conversion to forwarding mailbox user requires primary email address to be in authoritative domain')
            }
			
			
            $userData = removeMD $userData
			
			$userData = updateNewProxyAddresses $userData
                        
            $userdata = selectprimarymailboxdatabase $userdata
			
			enable-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -database $userdata.PrimaryDatabase -domaincontroller evcspidmgw1.ads.northwestern.edu
 			set-Mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			Set-Mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-Mailbox -Identity $userData.DN -EmailAddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu

			set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -identity $userData.DN -UseDatabaseQuotaDefaults $false -issuewarningQuota $userData.Warn -ProhibitSendQuota $userData.ProSend -ProhibitSendReceive $userData.ProSendRec -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu
            set-casmailbox -identity $userData.DN -owamailboxpolicy Default -domaincontroller evcspidmgw1.ads.northwestern.edu
			
            $userData = setForwardingContact $userData
			
            $userData = ChangeGalVis $userData
            $userData = updateNewProxyAddresses $userData
		   	set-mailbox -identity $userData.DN -primarysmtpaddress $userData.primaryemail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailbox -Identity $userData.DN -emailaddresses $userData.ProxyAddresses -domaincontroller evcspidmgw1.ads.northwestern.edu

			
			$userData = OldTypeToType $userData
  
  			return $userData
    }
	catch
	{
		Throw (New-Object System.Exception ('E0026: {0}' -f $_.Exception.Message))
	}
}


function FWDNOEMAILTOLISTING($userData)
{			
			
    try
    {	
            $userdata = VanityDomainMailuser $userdata
            $userdata = VanityDomainMailuser $userdata
            $userdata = VanityDomainMailuser $userdata
            $userdata = VanityDomainMailuser $userdata

            	
            if ((isPrimaryAddressInAuthDomain $userData) -or (isEmailAddressInLocalDomain $userData.primaryemail)) {
    			Throw (New-Object System.Exception 'Listing type requires primary email address to NOT be in authoritative domain')
            } 
			
			$userData = updateNewProxyAddresses $userData
                                    
            set-mailuser -identity $userData.DN -externalemailaddress $userData.PrimaryEmail  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            set-mailuser -identity $userData.DN -EmailAddressPolicyEnabled $false -emailaddresses $userData.ProxyAddresses  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
    		Throw (New-Object System.Exception ('E0027: {0}' -f $_.Exception.Message))
	}
}


function FWDNOEMAILTONONE($userData)
{
    try
    {		
            
            disable-mailuser -identity $userData.DN -Confirm:$false -domaincontroller evcspidmgw1.ads.northwestern.edu
            
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0028: {0}' -f $_.Exception.Message))
	}
}


function FWDWEMAILTOFULL($userData)
{
	try
	{
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata


            if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Conversion to full mailbox user requires primary email address to be in authoritative domain')
            } 

            $userData = removeMD $userData
			$userData = updateProxyAddresses $userData

            set-mailbox -identity $userData.DN  -ForwardingAddress $null -domaincontroller evcspidmgw1.ads.northwestern.edu
           
			$userData = updateProxyAddresses $userData
            $userData = ChangeGalVis $userData
           	$userData = OldTypeToType $userData
			
			return $userData
	}
	catch
	{
            Throw (New-Object System.Exception ('E0029: {0}' -f $_.Exception.Message))
	}
}


function FWDWEMAILTOFWDNOEMAIL($userData)
{			
           
    try
    {
            $userData = updateProxyAddresses $userData
			
           	disable-mailbox -identity $userData.DN -Confirm:$false -domaincontroller evcspidmgw1.ads.northwestern.edu
                              
            enable-mailuser -identity $userData.DN -externalemailaddress $userData.FwdEmail -domaincontroller evcspidmgw1.ads.northwestern.edu
            set-mailuser -identity $userData.DN -EmailAddressPolicyEnabled $false -emailaddresses $userData.ProxyAddresses  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            
           	$userData = ChangeGalvis $userData
           	$userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0030: {0}' -f $_.Exception.Message))
 	}
}

function FWDWEMAILTOFWDWEMAIL($userData)
{
	try
	{
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata

            if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Mail user type requires primary email address to be in authoritative domain')
            }
            $userData = removeMD $userData
			$userData = updateProxyAddresses $userData
			
	        set-Mailbox -Identity $userData.DN -EmailAddresses -$userData.ProxyAddresses
            
            #No longer updating quotas
            
            $userData = setForwardingContact $userData
			$userData = updateProxyAddresses $userData
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData

			return $userData
	}
	catch
	{
            Throw (New-Object System.Exception ('E0031: {0}' -f $_.Exception.Message))
	}
}

function FWDWEMAILTOLISTING($userData)
{
		
   try
    {	
            $userData = updateProxyAddresses $userData
            
            disable-mailbox -identity $userData.DN -Confirm:$false -domaincontroller evcspidmgw1.ads.northwestern.edu
                              
            enable-mailuser -identity $userData.DN -externalemailaddress $userData.PrimaryEmail -domaincontroller evcspidmgw1.ads.northwestern.edu
			set-mailuser -identity $userData.DN -EmailAddressPolicyEnabled $false -emailaddresses $userData.ProxyAddresses  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
			
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0032: {0}' -f $_.Exception.Message))
 	}
}


function FWDWEMAILTONONE($userData)
{
			
    try
    {

			disable-mailbox -identity $userData.DN -confirm:$false -domaincontroller evcspidmgw1.ads.northwestern.edu
			
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0036: {0}' -f $_.Exception.Message))
	}
}

function FULLTOFULL($userData)
{
 	try
	{
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata


            if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Mail user type requires primary email address to be in authoritative domain')
            } 
			
			
            $userData = removeMD $userData
			$userData = updateProxyAddresses $userData
			
		
			set-mailbox -Identity $userData.DN -PrimarySmtpAddress $userData.PrimaryEmail
			set-Mailbox -Identity $userData.DN -EmailAddresses $userData.ProxyAddresses

            $userData = ChangeGalVis $userData
			$userData = OldTypeToType $userData
			
			return $userData
	
}
	catch
	{
            Throw (New-Object System.Exception ('E0034: {0}' -f $_.Exception.Message))
	}
}



function FULLTOFWDNOEMAIL($userData)
{
			
    try
    {		
			$userData = updateProxyAddresses $userData
            
            disable-mailbox -identity $userData.DN -Confirm:$false -domaincontroller evcspidmgw1.ads.northwestern.edu
                              
            enable-mailuser -identity $userData.DN -externalemailaddress $userData.FwdEmail -domaincontroller evcspidmgw1.ads.northwestern.edu
			Set-MailUser -Identity $userData.DN -EmailAddressPolicyEnabled $false -EmailAddresses $userData.ProxyAddresses  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
			
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0037: {0}' -f $_.Exception.Message))
 	}
}
#
function FULLTOFWDWEMAIL($userData)
{
	try
	{
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata
            $userdata = VanityDomainMailbox $userdata

            if (!(isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Mailbox user type requires primary email address to be in authoritative domain')
            }
			
            $userData = removeMD $userData
			$userData = updateProxyAddresses $userData
			
			set-Mailbox -identity $userData.DN -EmailAddresses $userData.ProxyAddresses
			
            $userData = setForwardingContact $userData
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData

			return $userData
	}
	catch
	{
            Throw (New-Object System.Exception ('E0035: {0}' -f $_.Exception.Message))
	}
}


function FULLTOLISTING($userData)
{
			
   try
    {
            

            if ((isPrimaryAddressInAuthDomain $userData)) {
    			Throw (New-Object System.Exception 'Listing type requires primary email address to NOT be in authoritative domain')
            } 
			
			$userData = updateProxyAddresses $userData
            
            disable-mailbox -identity $userData.DN -Confirm:$false -domaincontroller evcspidmgw1.ads.northwestern.edu
			
            enable-mailuser -identity $userData.DN -externalemailaddress $userData.PrimaryEmail -domaincontroller evcspidmgw1.ads.northwestern.edu
			Set-MailUser -Identity $userData.DN -EmailAddressPolicyEnabled $false -EmailAddresses $userData.ProxyAddresses  -UseMapiRichTextFormat Never -domaincontroller evcspidmgw1.ads.northwestern.edu
            
            $userData = ChangeGalVis $userData
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0038: {0}' -f $_.Exception.Message))
    }
}



function FULLTONONE($userData)
{
		
    try
    {
			disable-mailbox -identity $userData.DN -Confirm:$false -domaincontroller evcspidmgw1.ads.northwestern.edu
			
            $userData = OldTypeToType $userData
			
			return $userData
    }
	catch
	{
            Throw (New-Object System.Exception ('E0039: {0}' -f $_.Exception.Message))
    }
}

#
#

################################################################################
# Main script processing starts here
################################################################################

try
{

	# Check that we were passed a Net ID parameter
	if ($netId -eq $null)
	{
		Throw (New-Object System.Exception 'E0001: No Net ID passed to this script')
	}

	# Search for the AD user for the given Net ID
	$userData = getADUserData $netId

    if ($userData.OldType) {
		$auditline = "Oldtype = " + $userData.oldtype.tostring() + ", Type = " + $userData.type.tostring()	
	} else {
		$auditline = "Oldtype = None" + ", Type = " + $userData.type.tostring()	
	}

	

    If (($userData.OldType -eq $null) -or ($userData.OldType.tolower() -eq "none")) {
        if ($userData.Type.tolower() -eq "full") {
            $userData = NONETOFULL $userData
        } elseif ($userData.Type.tolower() -eq "fwdnoemail") {
            $userData = NONETOFWDNOEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "fwdwithemail") {
            $userData = NONETOFWDWEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "listing") {
            $userData = NONETOLISTING $userData
        } elseif (($userData.Type.tolower() -eq $null) -or ($userData.Type.tolower() -eq "none")) {
            $userData = $userData
        } else {
            Throw (New-Object System.Exception 'E0003: Bad New Type with OldType = None')
        }
    } elseif ($userData.OldType.tolower() -eq "listing") {
        if ($userData.Type.tolower() -eq "full") {
            $userData = LISTINGTOFULL $userData
        } elseif ($userData.Type.tolower() -eq "fwdnoemail") {
            $userData = LISTINGTOFWDNOEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "fwdwithemail") {
            $userData = LISTINGTOFWDWEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "listing") {
            $userData = LISTINGTOLISTING $userData
        } elseif (($userData.Type.tolower() -eq $null) -or ($userData.Type.tolower() -eq "none")) {
            $userData = LISTINGTONONE $userData
        } else {
            Throw (New-Object System.Exception 'E0004: Bad New Type with OldType = listing')
        }
    } elseif ($userData.OldType.tolower() -eq "fwdnoemail") {
        if ($userData.Type.tolower() -eq "full") {
            $userData = FWDNOEMAILTOFULL $userData 
        } elseif ($userData.Type.tolower() -eq "fwdnoemail") {
            $userData = FWDNOEMAILTOFWDNOEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "fwdwithemail") {
            $userData = FWDNOEMAILTOFWDWEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "listing") {
            $userData = FWDNOEMAILTOLISTING $userData
        } elseif (($userData.Type.tolower() -eq $null) -or ($userData.Type.tolower() -eq "none")) {
            $userData = FWDNOEMAILTONONE $userData
        } else {
            Throw (New-Object System.Exception 'E0005: Bad New Type with OldType = FWDNOEMAIL')
        }
    } elseif ($userData.OldType.tolower() -eq "fwdwithemail") {
        if ($userData.Type.tolower() -eq "full") {
            $userData = FWDWEMAILTOFULL $userData
        } elseif ($userData.Type.tolower() -eq "fwdnoemail") {
            $userData = FWDWEMAILTOFWDNOEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "fwdwithemail") {
            $userData = FWDWEMAILTOFWDWEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "listing") {
            $userData = FWDWEMAILTOLISTING $userData
        } elseif (($userData.Type.tolower() -eq $null) -or ($userData.Type.tolower() -eq "none")) {
            $userData = FWDWEMAILTONONE $userData
        } else {
            Throw (New-Object System.Exception 'E0006: Bad New Type with OldType = FWDWEMAIL')
        }
    } elseif ($userData.OldType.tolower() -eq "full") {
        if ($userData.Type.tolower() -eq "full") {
            $userData = FULLTOFULL $userData 
        } elseif ($userData.Type.tolower() -eq "fwdnoemail") {
            $userData = FULLTOFWDNOEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "fwdwithemail") {
            $userData = FULLTOFWDWEMAIL $userData
        } elseif ($userData.Type.tolower() -eq "listing") {
            $userData = FULLTOLISTING $userData
        } elseif (($userData.Type.tolower() -eq $null) -or ($userData.Type.tolower() -eq "none")) {
            $userData = FULLTONONE $userData
        } else {
            Throw (New-Object System.Exception 'E0007: Bad New Type with OldType = FULL')
        }
	}
    else {
        Throw (New-Object System.Exception 'E0008: Bad OldType')
    }

    writeAuditSuccessLog $auditline

}
catch
{
	# this is the default error handling block
	writeError $_.Exception.Message
	exit 1
}
